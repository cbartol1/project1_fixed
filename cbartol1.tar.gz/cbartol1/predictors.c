#include<stddef.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>

void always_taken(char* file, int size, char* output) {

  // Temporary variables
  unsigned long long addr;
  char* behavior = malloc(size);
  unsigned long long target;
  int count = 0;
  int total = 0;

  // Open file for reading
  FILE *input = fopen(file, "r");

  while(fscanf(input, "%llx %10s %llx\n", &addr, behavior, &target) != EOF) {
    if(!strncmp(behavior, "T", 2)) {
      count++;
    }
    total++;
  }
  free(behavior);
  char str1[10];
  char str2[10];
  sprintf(str1, "%d", count);
  printf("%lld, %lld\n", count, total);
  FILE *out = fopen(output, "a");
  fputs(str1, out);
  sprintf(str2, "%d", total);
  fputs(", ", out);
  fputs(str2, out);
  fputs("\n", out);
  fclose(out);
  //return 0;
}

void always_ntaken(char *file, int size, char* output) {

  // Temporary variables
  unsigned long long addr;
  char* behavior = malloc(size);
  unsigned long long target;
  int count = 0;
  int total = 0;

  // Open file for reading
  FILE *input = fopen(file, "r");

  while(fscanf(input, "%llx %10s %llx\n", &addr, behavior, &target) != EOF) {
    if(strncmp(behavior, "T", 2)) {
      count++;
    }
    total++;
  }
  free(behavior);
  char str1[10];
  char str2[10];
  sprintf(str1, "%d", count);
  printf("%lld, %lld\n", count, total);
  FILE *out = fopen(output, "a");
  fputs(str1, out);
  sprintf(str2, "%d", total);
  fputs(", ", out);
  fputs(str2, out);
  fputs("\n", out);
  fclose(out);
  //return 0;
}

void bimodal_one_bit(char* file, int nlines, int nbits, char* output) {

  // Temporary variables
  unsigned long long addr;
  char* behavior = malloc(nlines);
  unsigned long long target;
  int taken = 1;
  int correct = 0;
  int table[nbits];
  int index;

  for(int i = 0; i < (sizeof(table)/sizeof(table[0])); i++){
        table[i] = 1;
  }

  int mask = nbits - 1;

  // Open file for reading
  FILE *input = fopen(file, "r");

  while(fscanf(input, "%llx %10s %llx\n", &addr, behavior, &target) != EOF) {
    index = addr & mask;
    if(!strncmp(behavior, "T", 2)) {
      if(table[index] == 1){
        correct++;
      }
      table[index] = 1;
    }
    else{
      if(table[index] == 0){
        correct++;
      }
      table[index] = 0;
    }
  }
  free(behavior);
  printf("%lld, %lld; ", correct, nlines);
  char str1[10];
  char str2[10];
  sprintf(str1, "%d", correct);
  FILE *out = fopen(output, "a");
  fputs(str1, out);
  sprintf(str2, "%d", nlines);
  fputs(", ", out);
  fputs(str2, out);
  fputs("; ", out);
  fclose(out);
  //return 0;
}

void bimodal_two_bit(char* file, int nlines, int nbits, char* output) {
 // Temporary variables
  unsigned long long addr;
  char* behavior = malloc(nlines);
  unsigned long long target;
  int taken = 1;
  int correct = 0;
  int table[nbits];
  int index;

  for(int i = 0; i < (sizeof(table)/sizeof(table[0])); i++){
        table[i] = 3;
  }

  int mask = nbits-1;

  // Open file for reading
  FILE *input = fopen(file, "r");

  while(fscanf(input, "%llx %10s %llx\n", &addr, behavior, &target) != EOF) {
    index = addr & mask;
    if(!strncmp(behavior, "T", 2)) {
      if(table[index] >= 2){
        correct++;
      }
      if(table[index] != 3) table[index]++;
    }
    else{
      if(table[index] < 2){
        correct++;
      }
      if(table[index] != 0) table[index]--;
    }
  }
  free(behavior);
  printf("%lld, %lld; ", correct, nlines);
  char str1[10];
  char str2[10];
  sprintf(str1, "%d", correct);
  FILE *out = fopen(output, "a");
  fputs(str1, out);
  sprintf(str2, "%d", nlines);
  fputs(", ", out);
  fputs(str2, out);
  fputs("; ", out);
  fclose(out);
  //return 0;
}
void gshare(char* file, int nlines, int nbits, char* output) {

  // Temporary variables
  unsigned long long addr;
  char* behavior = malloc(nlines);
  unsigned long long target;
  //int taken = 1;
  int correct = 0;
  int table[2048];
  int index;
  int ghr = 0;
  int mask = 2047;
  int ghrSize = 1;

  for(int i = 0; i < (sizeof(table)/sizeof(table[0])); i++){
        table[i] = 3;
  }

  for(int i = 0; i < nbits-1; i++){
	ghrSize = ghrSize << 1;
	ghrSize++;
  }
  //printf("mask is: %lld\n", mask);

  // Open file for reading
  FILE *input = fopen(file, "r");

  while(fscanf(input, "%llx %10s %llx\n", &addr, behavior, &target) != EOF) {
    index = addr & mask;
    //index = addr;
    ghr = ghr & ghrSize;
    index = index ^ ghr;
    //printf(" ghr = %lld, index = %lld\n", ghr, index);
    if(!strncmp(behavior, "T", 2)) {
      if(table[index] >= 2){
        correct++;
      }
      if(table[index] != 3) table[index]++;
      ghr = ghr << 1;
      ghr++;
    }
    else{
      if(table[index] < 2){
        correct++;
      }
      if(table[index] != 0) table[index]--;
      ghr = ghr << 1;
    }
  }
  free(behavior);
  printf("%lld, %lld; ", correct, nlines);
  char str1[10];
  char str2[10];
  sprintf(str1, "%d", correct);
  FILE *out = fopen(output, "a");
  fputs(str1, out);
  sprintf(str2, "%d", nlines);
  fputs(", ", out);
  fputs(str2, out);
  fputs("; ", out);
  fclose(out);
  //return 0;
}

void tournament(char* file, int nlines, char* output) {
  unsigned long long addr;
  char* behavior = malloc(nlines);
  unsigned long long target;
  //int taken = 1;
  int correct = 0;
  int gtable[2048];
  int btable[2048];
  int index;
  int gindex;
  int ghr = 0;
  int mask = 1;
  int ptable[2048];

  for(int i = 0; i < 2048; i++){
        gtable[i] = 3;
	btable[i] = 3;
	ptable[i] = 0;
  }

  for(int i = 0; i < 10; i++){
        mask = mask << 1;
        mask++;
  }

  // Open file for reading
  FILE *input = fopen(file, "r");

  while(fscanf(input, "%llx %10s %llx\n", &addr, behavior, &target) != EOF) {
    index = addr & 2047;
    ghr = ghr & mask;
    gindex = index ^ ghr;
    //printf(" ghr = %lld, index = %lld\n", ghr, index);
    if(!strncmp(behavior, "T", 2)) {
	if(gtable[gindex] >= 2 && btable[index] >= 2) correct++;
	else if(gtable[gindex] >= 2){
		if(ptable[index] < 2) correct++;
		if(ptable[index] != 0) ptable[index]--;
	}
	else if(btable[index] >= 2){
		if(ptable[index] >= 2) correct++;
		if(ptable[index] != 3) ptable[index]++;
	}
	if(btable[index] != 3) btable[index]++;
	if(gtable[gindex] != 3) gtable[gindex]++;
	ghr = ghr << 1;
	ghr++;
    }
    else{
	if(gtable[gindex] < 2 && btable[index] < 2) correct++;
        else if(gtable[gindex] < 2){
                if(ptable[index] < 2) correct++;
                if(ptable[index] != 0) ptable[index]--;
        }
        else if(btable[index] < 2){
                if(ptable[index] >= 2) correct++;
                if(ptable[index] != 3) ptable[index]++;
        }
        if(btable[index] != 0) btable[index]--;
        if(gtable[gindex] != 0) gtable[gindex]--;
	ghr = ghr << 1;
    }
  }
  free(behavior);
  printf("%lld, %lld\n", correct, nlines);
  char str1[10];
  char str2[10];
  sprintf(str1, "%d", correct);
  FILE *out = fopen(output, "a");
  fputs(str1, out);
  sprintf(str2, "%d", nlines);
  fputs(", ", out);
  fputs(str2, out);
  fputs("\n", out);
  fclose(out);
}

int main(int argc, char *argv[]) {
  FILE *fileptr;
    int count_lines = 0;
    char chr;
    fileptr = fopen(argv[1], "r");
   //extract character from file and store in chr
    chr = getc(fileptr);
    while (chr != EOF)
    {
        if (chr == '\n')
        {
            count_lines++;
        }
        chr = getc(fileptr);
    }
  //count_lines--; //this is to account for the last /n in the trace files
  fclose(fileptr);
  //printf("There are %d lines in %s  in a file\n", count_lines, argv[1]);
  always_taken(argv[1], count_lines, argv[2]);
  always_ntaken(argv[1], count_lines, argv[2]);
  for(int i = 16; i <= 2048; i = i*2){
    if(i != 64) bimodal_one_bit(argv[1], count_lines, i, argv[2]);
  }
  fileptr = fopen(argv[2], "a");
  fputs("\n", fileptr);
  fclose(fileptr);
  printf("\n");
  for(int i = 16; i <= 2048; i = i*2){
    if(i != 64) bimodal_two_bit(argv[1], count_lines, i, argv[2]);
  }
  fileptr = fopen(argv[2], "a");
  fputs("\n", fileptr);
  fclose(fileptr);
  printf("\n");
  for(int i = 3; i <= 11; i++){
    gshare(argv[1], count_lines, i, argv[2]);
  }
  fileptr = fopen(argv[2], "a");
  fputs("\n", fileptr);
  fclose(fileptr);
  printf("\n");
  tournament(argv[1], count_lines, argv[2]);
}
